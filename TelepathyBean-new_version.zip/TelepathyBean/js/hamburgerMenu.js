let x = document.getElementById("hiddenlinks");

function expandMenu() {
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
