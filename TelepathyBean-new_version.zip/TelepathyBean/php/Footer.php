<footer class="footer">
    <div class="footer-left">
        <h3>-> <span>Telepathy Bean</span></h3>

        <p class="footer-links">
            <a href="../index.php">Home</a>
            |
            <a href="#">News</a>
            |
            <a href="ProjectsPage.php">Projects</a>
            |
            <a href="ContactUsPage.php">Contact Us</a>
            |
            <a href="AboutUsPage.php">About Us</a>
            |
            <a href="MyProfilePage.php">My Profile</a>
        </p>

        <p class="footer-company-name">© 2020 Telepathy Bean Inc.</p>
    </div>

    <div class="footer-right">
        <p class="footer-company-about">
            <span>About the company</span>
            Startup. Fresh Solutions. Good Results.</p>
        <div class="footer-icons">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-youtube"></i></a>
        </div>
    </div>
</footer>